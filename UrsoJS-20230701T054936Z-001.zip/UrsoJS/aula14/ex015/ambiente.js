/*
var c = 1
while (c <= 5) {
    console.log(c)
    c++
} */

//---------------------------------

for(var c = 1;c <= 5;c++ ){
    console.log(c)
}